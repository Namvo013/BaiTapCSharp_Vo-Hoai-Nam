using System;
using System.Windows.Forms;

namespace DanhBa
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            // Cấu hình giao diện chuẩn cho ứng dụng Windows Forms
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            
            // Khởi chạy Form1 thuộc namespace DanhBa
            Application.Run(new Form1());
        }
    }
}