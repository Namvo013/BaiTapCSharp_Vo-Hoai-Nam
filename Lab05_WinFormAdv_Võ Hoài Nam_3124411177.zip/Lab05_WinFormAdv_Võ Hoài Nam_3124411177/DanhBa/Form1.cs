using System;
using System.Drawing;
using System.Windows.Forms;

namespace DanhBa
{
    public partial class Form1 : Form
    {
        private TreeView treeView;
        private TextBox txtFirstName;
        private TextBox txtLastName;
        private Button btnAdd;
        private Button btnExit;
        private ImageList imageList;

        public Form1()
        {
            InitializeForm();
            TaoDanhSachChuCai();
        }

        private void InitializeForm()
        {
            Text = "frmBTVN2";
            Size = new Size(720, 500);
            StartPosition = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            Font = new Font("Times New Roman", 12F);

            // 1. Khởi tạo ImageList 16x16 pixels
            imageList = new ImageList();
            imageList.ImageSize = new Size(16, 16);
            imageList.ColorDepth = ColorDepth.Depth32Bit;

            // --- 1. ICON THƯ MỤC ĐÓNG (Giống icon liên hệ con) ---
            Bitmap bmpClosed = new Bitmap(16, 16);
            using (Graphics g = Graphics.FromImage(bmpClosed))
            {
                g.Clear(Color.Transparent);
                g.FillRectangle(Brushes.Wheat, 2, 2, 12, 13);
                g.DrawRectangle(Pens.SaddleBrown, 2, 2, 12, 13);
                g.FillEllipse(Brushes.SaddleBrown, 6, 4, 4, 4);
                g.FillPie(Brushes.SaddleBrown, 4, 9, 8, 6, 180, 180);
            }
            imageList.Images.Add("folder_closed", bmpClosed);

            // --- 2. ICON THƯ MỤC MỞ CÓ HÌNH CÂY BÚT (Khi node chữ cái được mở rộng) ---
            Bitmap bmpOpen = new Bitmap(16, 16);
            using (Graphics g = Graphics.FromImage(bmpOpen))
            {
                g.Clear(Color.Transparent);
                g.FillRectangle(Brushes.LightYellow, 1, 2, 14, 12);
                g.DrawRectangle(Pens.DarkGoldenrod, 1, 2, 14, 12);
                g.DrawLine(Pens.SaddleBrown, 8, 2, 8, 14);
                g.DrawLine(Pens.Blue, 2, 13, 13, 2);
                g.DrawLine(Pens.Red, 12, 2, 14, 0);
            }
            imageList.Images.Add("folder_open", bmpOpen);

            // --- 3. ICON LIÊN LẠC CON ---
            Bitmap bmpContact = new Bitmap(16, 16);
            using (Graphics g = Graphics.FromImage(bmpContact))
            {
                g.Clear(Color.Transparent);
                g.FillRectangle(Brushes.Wheat, 2, 2, 12, 13);
                g.DrawRectangle(Pens.SaddleBrown, 2, 2, 12, 13);
                g.FillEllipse(Brushes.SaddleBrown, 6, 4, 4, 4);
                g.FillPie(Brushes.SaddleBrown, 4, 9, 8, 6, 180, 180);
            }
            imageList.Images.Add("contact", bmpContact);

            // 2. Cấu hình TreeView
            treeView = new TreeView
            {
                Location = new Point(10, 10),
                Size = new Size(290, 440),
                Font = new Font("Times New Roman", 14F),
                HideSelection = false,
                ImageList = imageList
            };

            treeView.AfterExpand += TreeView_AfterExpand;
            treeView.AfterCollapse += TreeView_AfterCollapse;

            GroupBox grpThongTin = new GroupBox
            {
                Text = "", // Đã xóa chữ tiêu đề của GroupBox
                Location = new Point(315, 35),
                Size = new Size(380, 190)
            };

            Label lblFirstName = new Label
            {
                Text = "Họ:",
                Location = new Point(20, 30),
                Size = new Size(100, 30)
            };

            txtFirstName = new TextBox
            {
                Location = new Point(125, 27),
                Size = new Size(230, 30)
            };

            Label lblLastName = new Label
            {
                Text = "Tên:",
                Location = new Point(20, 85),
                Size = new Size(100, 30)
            };

            txtLastName = new TextBox
            {
                Location = new Point(125, 82),
                Size = new Size(230, 30)
            };

            btnAdd = new Button
            {
                Text = "Thêm",
                Location = new Point(235, 135),
                Size = new Size(120, 35)
            };
            btnAdd.Click += BtnAdd_Click;

            grpThongTin.Controls.Add(lblFirstName);
            grpThongTin.Controls.Add(txtFirstName);
            grpThongTin.Controls.Add(lblLastName);
            grpThongTin.Controls.Add(txtLastName);
            grpThongTin.Controls.Add(btnAdd);

            btnExit = new Button
            {
                Text = "Thoát",
                Location = new Point(575, 245),
                Size = new Size(120, 35)
            };
            btnExit.Click += (s, e) => Close();

            Controls.Add(treeView);
            Controls.Add(grpThongTin);
            Controls.Add(btnExit);

            AcceptButton = btnAdd;
        }

        private void TaoDanhSachChuCai()
        {
            treeView.BeginUpdate();

            for (char c = 'A'; c <= 'Z'; c++)
            {
                TreeNode node = new TreeNode(c.ToString())
                {
                    ImageKey = "folder_closed",
                    SelectedImageKey = "folder_closed"
                };
                treeView.Nodes.Add(node);
            }

            treeView.EndUpdate();
        }

        private void TreeView_AfterExpand(object sender, TreeViewEventArgs e)
        {
            if (e.Node.Level == 0)
            {
                e.Node.ImageKey = "folder_open";
                e.Node.SelectedImageKey = "folder_open";
            }
        }

        private void TreeView_AfterCollapse(object sender, TreeViewEventArgs e)
        {
            if (e.Node.Level == 0)
            {
                e.Node.ImageKey = "folder_closed";
                e.Node.SelectedImageKey = "folder_closed";
            }
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            string firstName = txtFirstName.Text.Trim();
            string lastName = txtLastName.Text.Trim();

            if (string.IsNullOrWhiteSpace(firstName))
            {
                MessageBox.Show("Vui lòng nhập Họ!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtFirstName.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(lastName))
            {
                MessageBox.Show("Vui lòng nhập Tên!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtLastName.Focus();
                return;
            }

            char chuDau = char.ToUpperInvariant(firstName[0]);

            if (chuDau < 'A' || chuDau > 'Z')
            {
                MessageBox.Show("Họ phải bắt đầu bằng chữ cái A-Z!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtFirstName.Focus();
                return;
            }

            TreeNode nodeCha = treeView.Nodes[chuDau - 'A'];

            TreeNode newNode = new TreeNode(firstName + ", " + lastName)
            {
                ImageKey = "contact",
                SelectedImageKey = "contact"
            };

            nodeCha.Nodes.Add(newNode);
            nodeCha.Expand();

            txtFirstName.Clear();
            txtLastName.Clear();
            txtFirstName.Focus();
        }
    }
}