using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace TuDien
{
    public partial class Form1 : Form
    {
        private Dictionary<string, string> tuDien = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            { "student", "Sinh viên, học sinh" },
            { "teacher", "Giáo viên" },
            { "worker", "Công nhân" },
            { "hat", "Cái mũ" },
            { "head", "Cái đầu" },
            { "mouse", "Con chuột" },
            { "cat", "Con mèo" },
            { "dog", "Con chó" },
            { "snake", "Con rắn" },
            { "lumb", "Cái đèn" },
            { "loan", "Con sư tử" },
            { "frog", "Con ếch" },
            { "sheep", "Con cừu" }
        };

        private TabControl tabControl1;
        private TabPage tabAnhViet;
        private TabPage tabVietAnh;
        private ComboBox cboTuCanTra;
        private ListBox lstDanhSachTu;
        private TextBox txtNghia;
        private Button btnThoat;

        public Form1()
        {
            KhoiTaoGiaoDien();
            TaiDuLieuVaoDanhSach();
        }

        private void KhoiTaoGiaoDien()
        {
            // 1. Tăng kích thước Form để không bị méo/mất tiêu đề và nút bấm
            this.Text = "TỪ ĐIỂN ANH VIỆT - VIỆT ANH";
            this.Size = new Size(520, 460);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;

            // 2. TabControl vừa vặn với kích thước Form
            tabControl1 = new TabControl();
            tabControl1.Location = new Point(12, 12);
            tabControl1.Size = new Size(480, 350);

            tabAnhViet = new TabPage("ANH - VIỆT");
            tabVietAnh = new TabPage("VIỆT - ANH");

            tabControl1.TabPages.Add(tabAnhViet);
            tabControl1.TabPages.Add(tabVietAnh);

            // 3. Nhãn Tiếng Anh
            Label lblTiengAnh = new Label()
            {
                Text = "Tiếng Anh",
                Location = new Point(15, 12),
                AutoSize = true,
                Font = new Font("Segoe UI", 9.5F)
            };

            // 4. Nhãn Tiếng Việt
            Label lblTiengViet = new Label()
            {
                Text = "Tiếng Việt",
                Location = new Point(235, 12),
                AutoSize = true,
                Font = new Font("Segoe UI", 9.5F)
            };

            // 5. Ô nhập ComboBox (đặt Y = 38)
            cboTuCanTra = new ComboBox()
            {
                Location = new Point(15, 38),
                Size = new Size(200, 25),
                DropDownStyle = ComboBoxStyle.DropDown,
                Font = new Font("Segoe UI", 9.5F)
            };
            cboTuCanTra.KeyUp += CboTuCanTra_KeyUp;

            // 6. ListBox (đặt Y = 68 để đẩy xuống dưới ComboBox không lo bị chèn đè)
            lstDanhSachTu = new ListBox()
            {
                Location = new Point(15, 68),
                Size = new Size(200, 230),
                Font = new Font("Segoe UI", 9.5F)
            };
            lstDanhSachTu.SelectedIndexChanged += LstDanhSachTu_SelectedIndexChanged;
            lstDanhSachTu.DoubleClick += LstDanhSachTu_DoubleClick;

            // 7. Ô TextBox hiển thị nghĩa tiếng Việt
            txtNghia = new TextBox()
            {
                Location = new Point(235, 38),
                Size = new Size(220, 260),
                Multiline = true,
                ReadOnly = true,
                BackColor = Color.White,
                Font = new Font("Segoe UI", 9.5F)
            };

            // 8. Nút Thoát nằm hoàn toàn trong Form ở vị trí góc dưới bên phải
            btnThoat = new Button()
            {
                Text = "Thoát",
                Location = new Point(372, 372),
                Size = new Size(120, 32),
                Font = new Font("Segoe UI", 9.5F)
            };
            btnThoat.Click += (s, e) => this.Close();

            // Thêm các control vào Tab ANH - VIỆT
            tabAnhViet.Controls.Add(lblTiengAnh);
            tabAnhViet.Controls.Add(lblTiengViet);
            tabAnhViet.Controls.Add(cboTuCanTra);
            tabAnhViet.Controls.Add(lstDanhSachTu);
            tabAnhViet.Controls.Add(txtNghia);

            // Thêm TabControl và Nút Thoát vào Form
            this.Controls.Add(tabControl1);
            this.Controls.Add(btnThoat);
        }

        private void TaiDuLieuVaoDanhSach()
        {
            lstDanhSachTu.Items.Clear();
            cboTuCanTra.Items.Clear();

            foreach (var key in tuDien.Keys)
            {
                lstDanhSachTu.Items.Add(key);
                cboTuCanTra.Items.Add(key);
            }
        }

        private void CboTuCanTra_KeyUp(object sender, KeyEventArgs e)
        {
            string tuNhap = cboTuCanTra.Text;
            int index = lstDanhSachTu.FindString(tuNhap);
            if (index != -1)
            {
                lstDanhSachTu.SelectedIndex = index;
            }

            if (e.KeyCode == Keys.Enter)
            {
                HienThiNghia();
            }
        }

        private void LstDanhSachTu_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstDanhSachTu.SelectedItem != null)
            {
                cboTuCanTra.Text = lstDanhSachTu.SelectedItem.ToString();
            }
        }

        private void LstDanhSachTu_DoubleClick(object sender, EventArgs e)
        {
            HienThiNghia();
        }

        private void HienThiNghia()
        {
            if (lstDanhSachTu.SelectedItem != null)
            {
                string tuChon = lstDanhSachTu.SelectedItem.ToString();
                if (tuDien.ContainsKey(tuChon))
                {
                    txtNghia.Text = tuDien[tuChon];
                }
            }
            else if (!string.IsNullOrEmpty(cboTuCanTra.Text))
            {
                string tuNhap = cboTuCanTra.Text.Trim();
                if (tuDien.ContainsKey(tuNhap))
                {
                    txtNghia.Text = tuDien[tuNhap];
                }
                else
                {
                    txtNghia.Text = "Không tìm thấy từ này!";
                }
            }
        }
    }
}