using System;
using System.Drawing;
using System.Windows.Forms;

namespace DongHo
{
    public partial class Form1 : Form
    {
        private Label lblThoiGian;
        private Button btnBatDau;
        private System.Windows.Forms.Timer timer;
        private int soGiay = 1800;
        private bool dangChay = false;

        public Form1()
        {
            InitializeComponent();
            TaoGiaoDien();
        }

        private void TaoGiaoDien()
        {
            this.Controls.Clear();
            this.Text = "Đồng hồ";
            this.ClientSize = new Size(260, 135);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;

            lblThoiGian = new Label();
            lblThoiGian.Text = "30:00";
            lblThoiGian.Font = new Font("Arial", 18, FontStyle.Bold);
            lblThoiGian.TextAlign = ContentAlignment.MiddleCenter;
            lblThoiGian.Location = new Point(35, 10);
            lblThoiGian.Size = new Size(190, 35);

            btnBatDau = new Button();
            btnBatDau.Text = "Bắt đầu";
            btnBatDau.Font = new Font("Arial", 10);
            btnBatDau.Size = new Size(90, 35);
            btnBatDau.Location = new Point(85, 60);
            btnBatDau.Click += BtnBatDau_Click;

            timer = new System.Windows.Forms.Timer();
            timer.Interval = 1000;
            timer.Tick += Timer_Tick;

            this.Controls.Add(lblThoiGian);
            this.Controls.Add(btnBatDau);
        }

        private void BtnBatDau_Click(object sender, EventArgs e)
        {
            if (!dangChay)
            {
                if (soGiay <= 0)
                {
                    soGiay = 1800;
                    lblThoiGian.Text = "30:00";
                }

                dangChay = true;
                btnBatDau.Text = "Tạm dừng";
                timer.Start();
            }
            else
            {
                dangChay = false;
                btnBatDau.Text = "Tiếp tục";
                timer.Stop();
            }
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            if (soGiay > 0)
            {
                soGiay--;

                int phut = soGiay / 60;
                int giay = soGiay % 60;

                lblThoiGian.Text =
                    phut.ToString("00") + ":" + giay.ToString("00");
            }

            if (soGiay == 0)
            {
                timer.Stop();
                dangChay = false;
                btnBatDau.Text = "Bắt đầu";

                MessageBox.Show(
                    "Đã hết thời gian!",
                    "Đồng hồ",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
        }

        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            if (timer != null)
            {
                timer.Stop();
                timer.Dispose();
            }

            base.OnFormClosed(e);
        }
    }
}