using System;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace QuanLyLop
{
    public class Form1 : Form
    {
        private string connectionString = @"Data Source=.\SQLEXPRESS;Initial Catalog=QLSinhVien;Integrated Security=True;TrustServerCertificate=True";
        private TextBox txtMaKhoa;
        private TextBox txtMaLop;
        private TextBox txtTenLop;
        private Button btnAdd;
        private Button btnDelete;
        private Button btnUpdate;

        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "frmLop";
            this.Size = new Size(360, 240);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;

            Label lblMaKhoa = new Label() { Text = "Mã khoa", Location = new Point(20, 20), Width = 70 };
            txtMaKhoa = new TextBox() { Location = new Point(100, 20), Width = 210 };

            Label lblMaLop = new Label() { Text = "Mã lớp", Location = new Point(20, 60), Width = 70 };
            txtMaLop = new TextBox() { Location = new Point(100, 60), Width = 210 };

            Label lblTenLop = new Label() { Text = "Tên lớp", Location = new Point(20, 100), Width = 70 };
            txtTenLop = new TextBox() { Location = new Point(100, 100), Width = 210 };

            btnAdd = new Button() { Text = "Thêm", Location = new Point(20, 150), Size = new Size(90, 30) };
            btnDelete = new Button() { Text = "Xóa", Location = new Point(125, 150), Size = new Size(90, 30) };
            btnUpdate = new Button() { Text = "Sửa", Location = new Point(230, 150), Size = new Size(90, 30) };

            btnAdd.Click += btnAdd_Click;
            btnDelete.Click += btnDelete_Click;
            btnUpdate.Click += btnUpdate_Click;

            this.Controls.Add(lblMaKhoa);
            this.Controls.Add(txtMaKhoa);
            this.Controls.Add(lblMaLop);
            this.Controls.Add(txtMaLop);
            this.Controls.Add(lblTenLop);
            this.Controls.Add(txtTenLop);
            this.Controls.Add(btnAdd);
            this.Controls.Add(btnDelete);
            this.Controls.Add(btnUpdate);
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            // Kiểm tra không được để trống Mã khoa, Mã lớp, Tên lớp
            if (string.IsNullOrWhiteSpace(txtMaKhoa.Text) || 
                string.IsNullOrWhiteSpace(txtMaLop.Text) || 
                string.IsNullOrWhiteSpace(txtTenLop.Text))
            {
                MessageBox.Show("Mã khoa, Mã lớp và Tên lớp không được để trống!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = "INSERT INTO Lop (MaKhoa, MaLop, TenLop) VALUES (@MaKhoa, @MaLop, @TenLop)";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@MaKhoa", txtMaKhoa.Text.Trim());
                        cmd.Parameters.AddWithValue("@MaLop", txtMaLop.Text.Trim());
                        cmd.Parameters.AddWithValue("@TenLop", txtTenLop.Text.Trim());
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Thêm lớp thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            // Kiểm tra Mã lớp không được để trống
            if (string.IsNullOrWhiteSpace(txtMaLop.Text))
            {
                MessageBox.Show("Vui lòng nhập Mã lớp cần xóa!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = "DELETE FROM Lop WHERE MaLop = @MaLop";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@MaLop", txtMaLop.Text.Trim());
                        int rows = cmd.ExecuteNonQuery();
                        if (rows > 0)
                        {
                            MessageBox.Show("Xóa lớp thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("Không tìm thấy mã lớp cần xóa.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            // Kiểm tra Mã lớp không được để trống
            if (string.IsNullOrWhiteSpace(txtMaLop.Text))
            {
                MessageBox.Show("Mã lớp không được để trống khi sửa!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Kiểm tra Mã khoa hoặc Tên lớp phải có ít nhất 1 trường có dữ liệu
            if (string.IsNullOrWhiteSpace(txtMaKhoa.Text) && string.IsNullOrWhiteSpace(txtTenLop.Text))
            {
                MessageBox.Show("Phải nhập ít nhất Mã khoa hoặc Tên lớp để cập nhật!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    // Xây dựng câu lệnh động tùy thuộc vào trường nào được nhập
                    string query = "UPDATE Lop SET ";
                    bool hasField = false;

                    using (SqlCommand cmd = new SqlCommand())
                    {
                        if (!string.IsNullOrWhiteSpace(txtMaKhoa.Text))
                        {
                            query += "MaKhoa = @MaKhoa";
                            cmd.Parameters.AddWithValue("@MaKhoa", txtMaKhoa.Text.Trim());
                            hasField = true;
                        }

                        if (!string.IsNullOrWhiteSpace(txtTenLop.Text))
                        {
                            if (hasField) query += ", ";
                            query += "TenLop = @TenLop";
                            cmd.Parameters.AddWithValue("@TenLop", txtTenLop.Text.Trim());
                        }

                        query += " WHERE MaLop = @MaLop";
                        cmd.Parameters.AddWithValue("@MaLop", txtMaLop.Text.Trim());

                        cmd.Connection = conn;
                        cmd.CommandText = query;

                        int rows = cmd.ExecuteNonQuery();
                        if (rows > 0)
                        {
                            MessageBox.Show("Cập nhật thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("Không tìm thấy mã lớp cần sửa.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}