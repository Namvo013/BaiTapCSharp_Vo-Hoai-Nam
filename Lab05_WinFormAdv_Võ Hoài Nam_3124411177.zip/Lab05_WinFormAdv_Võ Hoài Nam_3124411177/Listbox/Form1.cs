
using System;
using System.Drawing;
using System.Windows.Forms;

namespace Listbox
{
    public partial class Form1 : Form
    {
        private Label lblTitle;
        private GroupBox grpListbox;
        private GroupBox grpXuLy;
        private TextBox txtNhap;
        private Button btnNhap;
        private ListBox lstSo;

        private Button btnTong;
        private Button btnXoaDauCuoi;
        private Button btnXoaDangChon;
        private Button btnTang2;
        private Button btnBinhPhuong;
        private Button btnChonChan;
        private Button btnChonLe;
        private Button btnKetThuc;

        public Form1()
        {
            KhoiTaoGiaoDien();
        }

        private void KhoiTaoGiaoDien()
        {
            Text = "frmListbox";
            ClientSize = new Size(620, 520);
            StartPosition = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            BackColor = Color.White;
            Font = new Font("Arial", 10F);

            lblTitle = new Label
            {
                Text = "LISTBOX",
                Font = new Font("Arial", 22F, FontStyle.Bold),
                ForeColor = Color.DarkOrange,
                TextAlign = ContentAlignment.MiddleCenter,
                Location = new Point(70, 10),
                Size = new Size(535, 65),
                BorderStyle = BorderStyle.FixedSingle
            };

            grpListbox = new GroupBox
            {
                Text = "Listbox",
                Location = new Point(20, 80),
                Size = new Size(220, 365),
                Font = new Font("Arial", 10F),
                BackColor = Color.White
            };

            txtNhap = new TextBox
            {
                Location = new Point(10, 22),
                Size = new Size(190, 32),
                Font = new Font("Arial", 12F)
            };

            btnNhap = TaoNut("Nhập", 10, 64, 190, 40);
            btnNhap.Click += BtnNhap_Click;

            lstSo = new ListBox
            {
                Location = new Point(10, 112),
                Size = new Size(190, 230),
                Font = new Font("Arial", 12F),
                SelectionMode = SelectionMode.MultiExtended,
                IntegralHeight = false
            };

            txtNhap.KeyDown += (s, e) =>
            {
                if (e.KeyCode == Keys.Enter)
                {
                    BtnNhap_Click(s, e);
                    e.SuppressKeyPress = true;
                }
            };

            grpListbox.Controls.Add(txtNhap);
            grpListbox.Controls.Add(btnNhap);
            grpListbox.Controls.Add(lstSo);

            grpXuLy = new GroupBox
            {
                Text = "Xử lý Listbox",
                Location = new Point(260, 80),
                Size = new Size(340, 365),
                Font = new Font("Arial", 10F),
                BackColor = Color.White
            };

            btnTong = TaoNut(
                "Tổng các phần tử trong List", 10, 24, 310, 39);
            btnTong.Click += BtnTong_Click;

            btnXoaDauCuoi = TaoNut(
                "Xóa Phần tử đầu và cuối", 10, 73, 310, 39);
            btnXoaDauCuoi.Click += BtnXoaDauCuoi_Click;

            btnXoaDangChon = TaoNut(
                "Xóa Phần tử đang chọn", 10, 122, 310, 39);
            btnXoaDangChon.Click += BtnXoaDangChon_Click;

            btnTang2 = TaoNut(
                "Tăng mỗi phần tử lên 2", 10, 171, 310, 39);
            btnTang2.Click += BtnTang2_Click;

            btnBinhPhuong = TaoNut(
                "Thay bằng bình phương", 10, 220, 310, 39);
            btnBinhPhuong.Click += BtnBinhPhuong_Click;

            btnChonChan = TaoNut(
                "Chọn số chẵn", 10, 269, 310, 39);
            btnChonChan.Click += BtnChonChan_Click;

            btnChonLe = TaoNut(
                "Chọn số lẻ", 10, 318, 310, 39);
            btnChonLe.Click += BtnChonLe_Click;

            grpXuLy.Controls.Add(btnTong);
            grpXuLy.Controls.Add(btnXoaDauCuoi);
            grpXuLy.Controls.Add(btnXoaDangChon);
            grpXuLy.Controls.Add(btnTang2);
            grpXuLy.Controls.Add(btnBinhPhuong);
            grpXuLy.Controls.Add(btnChonChan);
            grpXuLy.Controls.Add(btnChonLe);

            btnKetThuc = TaoNut(
                "KẾT THÚC", 20, 455, 580, 40);
            btnKetThuc.Font = new Font("Arial", 11F);
            btnKetThuc.Click += (s, e) => Close();

            Controls.Add(lblTitle);
            Controls.Add(grpListbox);
            Controls.Add(grpXuLy);
            Controls.Add(btnKetThuc);
        }

        private Button TaoNut(
            string text, int x, int y, int width, int height)
        {
            return new Button
            {
                Text = text,
                Location = new Point(x, y),
                Size = new Size(width, height),
                Font = new Font("Arial", 11F),
                FlatStyle = FlatStyle.Standard,
                UseVisualStyleBackColor = true,
                Cursor = Cursors.Hand
            };
        }

        private void BtnNhap_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtNhap.Text.Trim(), out int val)
                && val >= 0)
            {
                lstSo.Items.Add(val);
                txtNhap.Clear();
                txtNhap.Focus();
            }
            else
            {
                MessageBox.Show(
                    "Vui lòng nhập số tự nhiên hợp lệ!",
                    "Thông báo",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                txtNhap.Focus();
                txtNhap.SelectAll();
            }
        }

        private void BtnTong_Click(object sender, EventArgs e)
        {
            long tong = 0;

            foreach (var item in lstSo.Items)
            {
                tong += Convert.ToInt64(item);
            }

            MessageBox.Show(
                $"Tổng các phần tử trong Listbox là: {tong}",
                "Kết quả",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }

        private void BtnXoaDauCuoi_Click(object sender, EventArgs e)
        {
            if (lstSo.Items.Count == 0)
            {
                MessageBox.Show("Danh sách đang trống!");
                return;
            }

            if (lstSo.Items.Count == 1)
            {
                lstSo.Items.RemoveAt(0);
            }
            else
            {
                lstSo.Items.RemoveAt(lstSo.Items.Count - 1);
                lstSo.Items.RemoveAt(0);
            }
        }

        private void BtnXoaDangChon_Click(object sender, EventArgs e)
        {
            if (lstSo.SelectedIndices.Count == 0)
            {
                MessageBox.Show("Vui lòng chọn phần tử cần xóa!");
                return;
            }

            for (int i = lstSo.SelectedIndices.Count - 1; i >= 0; i--)
            {
                lstSo.Items.RemoveAt(lstSo.SelectedIndices[i]);
            }
        }

        private void BtnTang2_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < lstSo.Items.Count; i++)
            {
                long val = Convert.ToInt64(lstSo.Items[i]);
                lstSo.Items[i] = val + 2;
            }
        }

        private void BtnBinhPhuong_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < lstSo.Items.Count; i++)
            {
                long val = Convert.ToInt64(lstSo.Items[i]);

                try
                {
                    lstSo.Items[i] = checked(val * val);
                }
                catch (OverflowException)
                {
                    MessageBox.Show(
                        "Giá trị quá lớn để tính bình phương!",
                        "Thông báo",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                    return;
                }
            }
        }

        private void BtnChonChan_Click(object sender, EventArgs e)
        {
            lstSo.ClearSelected();

            for (int i = 0; i < lstSo.Items.Count; i++)
            {
                long val = Convert.ToInt64(lstSo.Items[i]);

                if (val % 2 == 0)
                    lstSo.SetSelected(i, true);
            }
        }

        private void BtnChonLe_Click(object sender, EventArgs e)
        {
            lstSo.ClearSelected();

            for (int i = 0; i < lstSo.Items.Count; i++)
            {
                long val = Convert.ToInt64(lstSo.Items[i]);

                if (val % 2 != 0)
                    lstSo.SetSelected(i, true);
            }
        }
    }
}
