
using System;
using System.Drawing;
using System.Windows.Forms;

namespace ThongTinSV
{
    public partial class Form1 : Form
    {
        private TextBox txtHoTen;
        private TextBox txtMaSV;
        private RadioButton radNam;
        private RadioButton radNu;
        private CheckBox chkAnh;
        private CheckBox chkPhap;
        private CheckBox chkHoa;
        private ComboBox cboDanToc;
        private DataGridView dgvSinhVien;
        private Panel pnlNoiDung;

        public Form1()
        {
            InitializeComponent();
            TaoGiaoDien();
        }

        private void TaoGiaoDien()
        {
            this.Controls.Clear();
            this.Text = "BTVN_Tuan6";
            this.StartPosition = FormStartPosition.CenterScreen;
            this.ClientSize = new Size(700, 560);
            this.MinimumSize = new Size(716, 599);
            this.Font = new Font("Arial", 10);
            this.IsMdiContainer = false;

            MenuStrip menuStrip = new MenuStrip();
            ToolStripMenuItem menuBai1 = new ToolStripMenuItem("Bài 1");
            ToolStripMenuItem menuBai2 = new ToolStripMenuItem("Bài 2");
            ToolStripMenuItem menuKhac = new ToolStripMenuItem("....");

            menuStrip.Items.AddRange(new ToolStripItem[]
            {
                menuBai1, menuBai2, menuKhac
            });

            this.MainMenuStrip = menuStrip;
            this.Controls.Add(menuStrip);

            pnlNoiDung = new Panel();
            pnlNoiDung.Location = new Point(10, 35);
            pnlNoiDung.Size = new Size(680, 515);
            pnlNoiDung.Anchor = AnchorStyles.Top | AnchorStyles.Bottom
                              | AnchorStyles.Left | AnchorStyles.Right;
            this.Controls.Add(pnlNoiDung);

            menuBai1.Click += (s, e) => HienThiBai1();
            menuBai2.Click += (s, e) =>
            {
                MessageBox.Show(
                    "Bài 2 chưa được xây dựng.",
                    "Thông báo",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            };

            HienThiBai1();
        }

        private void HienThiBai1()
        {
            pnlNoiDung.Controls.Clear();

            Label lblTieuDe = new Label();
            lblTieuDe.Text = "Thông tin sinh viên";
            lblTieuDe.Font = new Font("Arial", 14, FontStyle.Bold);
            lblTieuDe.Location = new Point(220, 10);
            lblTieuDe.Size = new Size(250, 30);

            Label lblHoTen = new Label();
            lblHoTen.Text = "Họ và Tên";
            lblHoTen.Location = new Point(35, 60);
            lblHoTen.Size = new Size(130, 25);

            txtHoTen = new TextBox();
            txtHoTen.Location = new Point(220, 57);
            txtHoTen.Size = new Size(280, 28);

            Label lblMaSV = new Label();
            lblMaSV.Text = "Mã sinh viên";
            lblMaSV.Location = new Point(35, 105);
            lblMaSV.Size = new Size(130, 25);

            txtMaSV = new TextBox();
            txtMaSV.Location = new Point(220, 102);
            txtMaSV.Size = new Size(280, 28);

            Label lblGioiTinh = new Label();
            lblGioiTinh.Text = "Giới tính";
            lblGioiTinh.Location = new Point(35, 150);
            lblGioiTinh.Size = new Size(130, 25);

            radNam = new RadioButton();
            radNam.Text = "Nam";
            radNam.Location = new Point(220, 148);
            radNam.Size = new Size(70, 25);
            radNam.Checked = true;

            radNu = new RadioButton();
            radNu.Text = "Nữ";
            radNu.Location = new Point(330, 148);
            radNu.Size = new Size(70, 25);

            Label lblNgoaiNgu = new Label();
            lblNgoaiNgu.Text = "Ngoại ngữ";
            lblNgoaiNgu.Location = new Point(35, 195);
            lblNgoaiNgu.Size = new Size(130, 25);

            chkAnh = new CheckBox();
            chkAnh.Text = "Anh";
            chkAnh.Location = new Point(220, 193);
            chkAnh.Size = new Size(65, 25);
            chkAnh.Checked = true;

            chkPhap = new CheckBox();
            chkPhap.Text = "Pháp";
            chkPhap.Location = new Point(320, 193);
            chkPhap.Size = new Size(75, 25);

            chkHoa = new CheckBox();
            chkHoa.Text = "Hoa";
            chkHoa.Location = new Point(420, 193);
            chkHoa.Size = new Size(65, 25);

            Label lblDanToc = new Label();
            lblDanToc.Text = "Dân tộc";
            lblDanToc.Location = new Point(35, 240);
            lblDanToc.Size = new Size(130, 25);

            cboDanToc = new ComboBox();
            cboDanToc.Location = new Point(220, 237);
            cboDanToc.Size = new Size(280, 28);
            cboDanToc.DropDownStyle = ComboBoxStyle.DropDownList;
            cboDanToc.Items.AddRange(new object[]
            {
                "Kinh", "Tày", "Thái", "Mường", "Khmer",
                "Hoa", "Nùng", "H'Mông", "Dao", "Khác"
            });
            cboDanToc.SelectedIndex = 0;

            Button btnThem = new Button();
            btnThem.Text = "Thêm";
            btnThem.Location = new Point(220, 280);
            btnThem.Size = new Size(80, 32);
            btnThem.Click += BtnThem_Click;

            Button btnXoa = new Button();
            btnXoa.Text = "Xóa";
            btnXoa.Location = new Point(315, 280);
            btnXoa.Size = new Size(80, 32);
            btnXoa.Click += BtnXoa_Click;

            Button btnLamMoi = new Button();
            btnLamMoi.Text = "Làm mới";
            btnLamMoi.Location = new Point(410, 280);
            btnLamMoi.Size = new Size(90, 32);
            btnLamMoi.Click += (s, e) => XoaTrang();

            dgvSinhVien = new DataGridView();
            dgvSinhVien.Location = new Point(15, 330);
            dgvSinhVien.Size = new Size(650, 165);
            dgvSinhVien.AllowUserToAddRows = false;
            dgvSinhVien.ReadOnly = true;
            dgvSinhVien.MultiSelect = false;
            dgvSinhVien.SelectionMode =
                DataGridViewSelectionMode.FullRowSelect;
            dgvSinhVien.AutoSizeColumnsMode =
                DataGridViewAutoSizeColumnsMode.Fill;
            dgvSinhVien.RowHeadersVisible = false;

            dgvSinhVien.Columns.Add("HoTen", "Họ tên");
            dgvSinhVien.Columns.Add("MaSV", "Mã sinh viên");
            dgvSinhVien.Columns.Add("GioiTinh", "Giới tính");
            dgvSinhVien.Columns.Add("NgoaiNgu", "Ngoại ngữ");
            dgvSinhVien.Columns.Add("DanToc", "Dân tộc");

            pnlNoiDung.Controls.AddRange(new Control[]
            {
                lblTieuDe,
                lblHoTen, txtHoTen,
                lblMaSV, txtMaSV,
                lblGioiTinh, radNam, radNu,
                lblNgoaiNgu, chkAnh, chkPhap, chkHoa,
                lblDanToc, cboDanToc,
                btnThem, btnXoa, btnLamMoi,
                dgvSinhVien
            });
        }

        private void BtnThem_Click(object sender, EventArgs e)
        {
            string hoTen = txtHoTen.Text.Trim();
            string maSV = txtMaSV.Text.Trim();

            if (hoTen == "" || maSV == "")
            {
                MessageBox.Show("Vui lòng nhập đầy đủ họ tên và mã sinh viên!");
                return;
            }

            foreach (DataGridViewRow row in dgvSinhVien.Rows)
            {
                if (string.Equals(
                    Convert.ToString(row.Cells["MaSV"].Value),
                    maSV,
                    StringComparison.OrdinalIgnoreCase))
                {
                    MessageBox.Show("Mã sinh viên đã tồn tại!");
                    return;
                }
            }

            string gioiTinh = radNam.Checked ? "Nam" : "Nữ";
            string ngoaiNgu = "";

            if (chkAnh.Checked) ngoaiNgu += "Anh, ";
            if (chkPhap.Checked) ngoaiNgu += "Pháp, ";
            if (chkHoa.Checked) ngoaiNgu += "Hoa, ";

            ngoaiNgu = ngoaiNgu.TrimEnd(',', ' ');

            dgvSinhVien.Rows.Add(
                hoTen, maSV, gioiTinh, ngoaiNgu, cboDanToc.Text);

            XoaTrang();
        }

        private void BtnXoa_Click(object sender, EventArgs e)
        {
            if (dgvSinhVien.SelectedRows.Count == 0)
            {
                MessageBox.Show("Vui lòng chọn sinh viên cần xóa!");
                return;
            }

            DialogResult ketQua = MessageBox.Show(
                "Bạn có chắc muốn xóa sinh viên này?",
                "Xác nhận",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (ketQua == DialogResult.Yes)
                dgvSinhVien.Rows.RemoveAt(
                    dgvSinhVien.SelectedRows[0].Index);
        }

        private void XoaTrang()
        {
            txtHoTen.Clear();
            txtMaSV.Clear();
            radNam.Checked = true;
            chkAnh.Checked = true;
            chkPhap.Checked = false;
            chkHoa.Checked = false;
            cboDanToc.SelectedIndex = 0;
            txtHoTen.Focus();
        }
    }
}
