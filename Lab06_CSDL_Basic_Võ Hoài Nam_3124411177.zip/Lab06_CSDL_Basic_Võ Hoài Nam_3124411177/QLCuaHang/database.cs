
using Microsoft.Data.SqlClient;

namespace QLCuaHang;

internal static class Database
{
    private const string ConnectionString =
        @"Data Source=.\SQLEXPRESS;Initial Catalog=QLCuaHang;Integrated Security=True;TrustServerCertificate=True";

    public static SqlConnection OpenConnection()
    {
        var conn = new SqlConnection(ConnectionString);

        try
        {
            conn.Open();
            return conn;
        }
        catch
        {
            conn.Dispose();
            throw;
        }
    }
}
