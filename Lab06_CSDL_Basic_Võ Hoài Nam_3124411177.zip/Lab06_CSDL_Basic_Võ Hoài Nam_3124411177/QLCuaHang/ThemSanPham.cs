using System;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace QLCuaHang
{
    public partial class ThemSanPham : Form
    {
        private TextBox txtTenSanPham;
        private Button btnThem;
        private Button btnThoat;

        public ThemSanPham()
        {
            KhoiTaoGiaoDienThuan();
        }

        private void KhoiTaoGiaoDienThuan()
        {
            this.Text = "Thêm sản phẩm mới";
            this.Size = new Size(450, 250);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.FromArgb(240, 240, 240);

            Label lbl = new Label();
            lbl.Text = "Tên sản phẩm";
            lbl.Location = new Point(30, 45);
            lbl.AutoSize = true;
            this.Controls.Add(lbl);

            txtTenSanPham = new TextBox();
            txtTenSanPham.Location = new Point(140, 42);
            txtTenSanPham.Size = new Size(250, 25);
            this.Controls.Add(txtTenSanPham);

            btnThem = new Button();
            btnThem.Text = "Thêm";
            btnThem.Location = new Point(140, 100);
            btnThem.Size = new Size(90, 32);
            btnThem.Click += btnThem_Click;
            this.Controls.Add(btnThem);

            btnThoat = new Button();
            btnThoat.Text = "Thoát";
            btnThoat.Location = new Point(300, 100);
            btnThoat.Size = new Size(90, 32);
            btnThoat.Click += (_, _) => this.Close();
            this.Controls.Add(btnThoat);
        }

        private void btnThem_Click(object? sender, EventArgs e)
        {
            string tenSanPham = txtTenSanPham.Text.Trim();

            if (string.IsNullOrEmpty(tenSanPham))
            {
                MessageBox.Show("Vui lòng nhập tên sản phẩm!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtTenSanPham.Focus();
                return;
            }

            try
            {
                using var conn = Database.OpenConnection();
                // Sửa thành cột TenSP cho khớp với CSDL của bạn
                string query = "INSERT INTO dbo.SANPHAM (TenSP) VALUES (@TenSP)";
                using var cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@TenSP", tenSanPham);
                cmd.ExecuteNonQuery();

                MessageBox.Show("Thêm sản phẩm thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtTenSanPham.Clear();
                txtTenSanPham.Focus();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi thêm sản phẩm: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}