using System;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace QLCuaHang
{
    public partial class BanHang : Form
    {
        private TextBox txtMaHoaDon;
        private ComboBox cboMaSanPham;
        private TextBox txtSoLuong;
        private Button btnTaoHoaDonMoi;
        private Button btnThemChiTiet;

        public BanHang()
        {
            KhoiTaoGiaoDienThuan();
            LoadDanhSachSanPham();
        }

        private void KhoiTaoGiaoDienThuan()
        {
            this.Text = "BanHang";
            this.Size = new Size(550, 420);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.FromArgb(240, 240, 240);

            btnTaoHoaDonMoi = new Button();
            btnTaoHoaDonMoi.Text = "Tạo hóa đơn mới";
            btnTaoHoaDonMoi.Location = new Point(360, 30);
            btnTaoHoaDonMoi.Size = new Size(130, 35);
            btnTaoHoaDonMoi.Click += btnTaoHoaDonMoi_Click;
            this.Controls.Add(btnTaoHoaDonMoi);

            GroupBox grpChiTiet = new GroupBox();
            grpChiTiet.Text = "Chi tiết hóa đơn";
            grpChiTiet.Location = new Point(40, 85);
            grpChiTiet.Size = new Size(450, 220);
            this.Controls.Add(grpChiTiet);

            Label lbl1 = new Label();
            lbl1.Text = "Mã hóa đơn";
            lbl1.Location = new Point(30, 40);
            lbl1.AutoSize = true;
            grpChiTiet.Controls.Add(lbl1);

            txtMaHoaDon = new TextBox();
            txtMaHoaDon.Location = new Point(150, 37);
            txtMaHoaDon.Size = new Size(250, 25);
            txtMaHoaDon.ReadOnly = true;
            grpChiTiet.Controls.Add(txtMaHoaDon);

            Label lbl2 = new Label();
            lbl2.Text = "Sản phẩm";
            lbl2.Location = new Point(30, 90);
            lbl2.AutoSize = true;
            grpChiTiet.Controls.Add(lbl2);

            cboMaSanPham = new ComboBox();
            cboMaSanPham.Location = new Point(150, 87);
            cboMaSanPham.Size = new Size(250, 25);
            cboMaSanPham.DropDownStyle = ComboBoxStyle.DropDownList;
            grpChiTiet.Controls.Add(cboMaSanPham);

            Label lbl3 = new Label();
            lbl3.Text = "Số lượng";
            lbl3.Location = new Point(30, 140);
            lbl3.AutoSize = true;
            grpChiTiet.Controls.Add(lbl3);

            txtSoLuong = new TextBox();
            txtSoLuong.Location = new Point(150, 137);
            txtSoLuong.Size = new Size(250, 25);
            grpChiTiet.Controls.Add(txtSoLuong);

            btnThemChiTiet = new Button();
            btnThemChiTiet.Text = "Thêm";
            btnThemChiTiet.Location = new Point(210, 175);
            btnThemChiTiet.Size = new Size(90, 30);
            btnThemChiTiet.Click += btnThemChiTiet_Click;
            grpChiTiet.Controls.Add(btnThemChiTiet);

            Button btnHuy = new Button();
            btnHuy.Text = "Hủy";
            btnHuy.Location = new Point(310, 175);
            btnHuy.Size = new Size(90, 30);
            btnHuy.Click += (_, _) => this.Close();
            grpChiTiet.Controls.Add(btnHuy);
        }

        private void LoadDanhSachSanPham()
        {
            try
            {
                using var conn = Database.OpenConnection();
                // Khớp tên cột MaSP và TenSP trong bảng SANPHAM
                string query = "SELECT MaSP, TenSP FROM dbo.SANPHAM";
                using var adapter = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);

                cboMaSanPham.DataSource = dt;
                cboMaSanPham.DisplayMember = "TenSP";
                cboMaSanPham.ValueMember = "MaSP";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Không thể tải danh sách sản phẩm: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnTaoHoaDonMoi_Click(object? sender, EventArgs e)
        {
            try
            {
                using var conn = Database.OpenConnection();
                // Khớp bảng HOADON với cột MaHD và NgayTao dùng DEFAULT GETDATE()
                string query = "INSERT INTO dbo.HOADON DEFAULT VALUES; SELECT SCOPE_IDENTITY();";
                
                // Hoặc dùng câu lệnh lấy OUTPUT MaHD:
                string queryOutput = "INSERT INTO dbo.HOADON (TinhTrangThanhToan) OUTPUT INSERTED.MaHD VALUES (0)";
                
                using var cmd = new SqlCommand(queryOutput, conn);
                int maHoaDonMoi = Convert.ToInt32(cmd.ExecuteScalar());

                txtMaHoaDon.Text = maHoaDonMoi.ToString();
                MessageBox.Show($"Đã tạo hóa đơn mới thành công! Mã hóa đơn: {maHoaDonMoi}", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tạo hóa đơn: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnThemChiTiet_Click(object? sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtMaHoaDon.Text) || string.IsNullOrEmpty(txtSoLuong.Text))
            {
                MessageBox.Show("Vui lòng tạo hóa đơn và nhập đầy đủ số lượng!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!int.TryParse(txtSoLuong.Text, out int soLuong) || soLuong <= 0)
            {
                MessageBox.Show("Số lượng phải là số nguyên lớn hơn 0!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int maHD = int.Parse(txtMaHoaDon.Text);
            int maSP = Convert.ToInt32(cboMaSanPham.SelectedValue);

            try
            {
                using var conn = Database.OpenConnection();
                // Khớp bảng CHITIET_HOADON với MaHD, MaSP, SoLuong
                string query = "INSERT INTO dbo.CHITIET_HOADON (MaHD, MaSP, SoLuong) VALUES (@MaHD, @MaSP, @SoLuong)";
                using var cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@MaHD", maHD);
                cmd.Parameters.AddWithValue("@MaSP", maSP);
                cmd.Parameters.AddWithValue("@SoLuong", soLuong);
                cmd.ExecuteNonQuery();

                MessageBox.Show("Đã thêm sản phẩm vào hóa đơn!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtSoLuong.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi thêm chi tiết hóa đơn: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}