using System;
using System.Drawing;
using System.Windows.Forms;

namespace QLCuaHang
{
    public partial class Form1 : Form
    {
        private Panel pnlMenu;
        private Panel pnlNoiDung;
        private Label lblTieuDe;

        private Button btnTonKho;
        private Button btnSanPham;
        private Button btnBanHang;
        private Button btnKiemTraKetNoi;
        private Button btnDangXuat;
        
        private Button? activeButton = null; // Quản lý nút đang được chọn trên menu

        public Form1()
        {
            InitializeComponent();
            TaoGiaoDien();
        }

        private void TaoGiaoDien()
        {
            Text = "QUẢN LÝ CỬA HÀNG";
            StartPosition = FormStartPosition.CenterScreen;
            Size = new Size(1000, 650);
            MinimumSize = new Size(850, 550);
            Font = new Font("Segoe UI", 10);
            BackColor = Color.White;

            pnlMenu = new Panel();
            pnlMenu.Dock = DockStyle.Left;
            pnlMenu.Width = 220;
            pnlMenu.BackColor = Color.FromArgb(35, 45, 65);

            Label lblLogo = new Label();
            lblLogo.Text = "QUẢN LÝ\nCỬA HÀNG";
            lblLogo.ForeColor = Color.White;
            lblLogo.Font = new Font("Segoe UI", 17, FontStyle.Bold);
            lblLogo.TextAlign = ContentAlignment.MiddleCenter;
            lblLogo.Dock = DockStyle.Top;
            lblLogo.Height = 110;

            btnTonKho = TaoNutMenu("Quản lý tồn kho", 140);
            btnSanPham = TaoNutMenu("Quản lý sản phẩm", 200);
            btnBanHang = TaoNutMenu("Bán hàng / Hóa đơn", 260);
            btnKiemTraKetNoi = TaoNutMenu("Kiểm tra kết nối SQL", 320);
            btnDangXuat = TaoNutMenu("Đăng xuất / Thoát", 380);

            // Sự kiện các nút menu
            btnTonKho.Click += (sender, _) =>
            {
                if (sender is Button btn) ChonNutMenu(btn);
                HienThiNoiDung("QUẢN LÝ TỒN KHO",
                    "Chức năng xem và cập nhật tồn kho sẽ được xây dựng ở bước tiếp theo.");
            };

            btnSanPham.Click += (sender, _) =>
            {
                if (sender is Button btn) ChonNutMenu(btn);
                HienThiNoiDung("QUẢN LÝ SẢN PHẨM", "Đang mở giao diện Quản lý sản phẩm...");
                
                // Gọi chính xác class ThemSanPham
                ThemSanPham frm = new ThemSanPham();
                frm.ShowDialog();
            };

            btnBanHang.Click += (sender, _) =>
            {
                if (sender is Button btn) ChonNutMenu(btn);
                HienThiNoiDung("BÁN HÀNG / HÓA ĐƠN", "Đang mở giao diện Bán hàng...");
                
                // Gọi chính xác class BanHang
                BanHang frm = new BanHang();
                frm.ShowDialog();
            };

            btnKiemTraKetNoi.Click += (sender, e) =>
            {
                if (sender is Button btn) ChonNutMenu(btn);
                BtnKiemTraKetNoi_Click(sender, e);
            };

            btnDangXuat.Click += (_, _) =>
            {
                var result = MessageBox.Show("Bạn có chắc chắn muốn thoát ứng dụng?", "Xác nhận thoát", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    Application.Exit();
                }
            };

            pnlMenu.Controls.AddRange(new Control[]
            {
                lblLogo,
                btnTonKho,
                btnSanPham,
                btnBanHang,
                btnKiemTraKetNoi,
                btnDangXuat
            });

            Panel pnlThanhTieuDe = new Panel();
            pnlThanhTieuDe.Dock = DockStyle.Top;
            pnlThanhTieuDe.Height = 65;
            pnlThanhTieuDe.BackColor = Color.FromArgb(240, 244, 248);

            lblTieuDe = new Label();
            lblTieuDe.Text = "TRANG CHỦ";
            lblTieuDe.Font = new Font("Segoe UI", 16, FontStyle.Bold);
            lblTieuDe.ForeColor = Color.FromArgb(35, 45, 65);
            lblTieuDe.Dock = DockStyle.Fill;
            lblTieuDe.TextAlign = ContentAlignment.MiddleLeft;
            lblTieuDe.Padding = new Padding(20, 0, 0, 0);

            pnlThanhTieuDe.Controls.Add(lblTieuDe);

            pnlNoiDung = new Panel();
            pnlNoiDung.Dock = DockStyle.Fill;
            pnlNoiDung.BackColor = Color.WhiteSmoke;

            Controls.Add(pnlNoiDung);
            Controls.Add(pnlThanhTieuDe);
            Controls.Add(pnlMenu);

            HienThiNoiDung(
                "CHƯƠNG TRÌNH QUẢN LÝ CỬA HÀNG",
                "Chọn chức năng ở menu bên trái để bắt đầu.");
        }

        private Button TaoNutMenu(string noiDung, int viTriY)
        {
            Button btn = new Button();
            btn.Text = noiDung;
            btn.Location = new Point(10, viTriY);
            btn.Size = new Size(200, 48);
            btn.FlatStyle = FlatStyle.Flat;
            btn.FlatAppearance.BorderSize = 0;
            btn.BackColor = Color.FromArgb(35, 45, 65);
            btn.ForeColor = Color.White;
            btn.Font = new Font("Segoe UI", 10);
            btn.TextAlign = ContentAlignment.MiddleLeft;
            btn.Padding = new Padding(12, 0, 0, 0);
            btn.Cursor = Cursors.Hand;

            return btn;
        }

        private void ChonNutMenu(Button btn)
        {
            if (activeButton != null)
            {
                activeButton.BackColor = Color.FromArgb(35, 45, 65); // Màu gốc
            }

            activeButton = btn;
            activeButton.BackColor = Color.FromArgb(55, 70, 95); // Màu sáng hơn khi được chọn
        }

        private void HienThiNoiDung(string tieuDe, string noiDung)
        {
            lblTieuDe.Text = tieuDe;
            pnlNoiDung.Controls.Clear();

            Label lblNoiDung = new Label();
            lblNoiDung.Text = noiDung;
            lblNoiDung.Font = new Font("Segoe UI", 13);
            lblNoiDung.ForeColor = Color.FromArgb(60, 70, 85);
            lblNoiDung.TextAlign = ContentAlignment.MiddleCenter;
            lblNoiDung.Dock = DockStyle.Fill;
            lblNoiDung.Padding = new Padding(30);

            pnlNoiDung.Controls.Add(lblNoiDung);
        }

        private void BtnKiemTraKetNoi_Click(object? sender, EventArgs e)
        {
            try
            {
                using var conn = Database.OpenConnection();

                MessageBox.Show(
                    "Kết nối database QLCuaHang thành công!",
                    "Thông báo",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Lỗi kết nối database:\n" + ex.Message,
                    "Lỗi SQL Server",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }
    }
}