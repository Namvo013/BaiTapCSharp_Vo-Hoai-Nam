
IF DB_ID(N'QLSinhVien') IS NULL
    CREATE DATABASE QLSinhVien;
GO

USE QLSinhVien;
GO

IF OBJECT_ID(N'dbo.Lop', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Lop
    (
        MaLop NVARCHAR(20) NOT NULL PRIMARY KEY,
        MaKhoa NVARCHAR(20) NOT NULL,
        TenLop NVARCHAR(100) NOT NULL
    );
END;
GO

SELECT * FROM dbo.Lop;
GO
