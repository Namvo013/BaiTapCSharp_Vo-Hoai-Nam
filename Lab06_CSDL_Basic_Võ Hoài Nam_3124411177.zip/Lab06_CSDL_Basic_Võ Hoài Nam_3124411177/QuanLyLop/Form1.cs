
using System;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace QuanLyLop
{
    public partial class Form1 : Form
    {
        private TextBox txtMaKhoa;
        private TextBox txtMaLop;
        private TextBox txtTenLop;
        private Button btnThem;
        private Button btnXoa;
        private Button btnSua;

        private readonly string connectionString =
    @"Data Source=.\SQLEXPRESS;Initial Catalog=QLSinhVien;Integrated Security=True;TrustServerCertificate=True";
        public Form1()
        {
            InitializeComponent();
            TaoGiaoDien();
        }

        private void TaoGiaoDien()
        {
            this.Controls.Clear();

            this.Text = "frmLop";
            this.ClientSize = new Size(400, 285);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Font = new Font("Arial", 10);

            Label lblMaKhoa = new Label();
            lblMaKhoa.Text = "Mã khoa";
            lblMaKhoa.Location = new Point(30, 30);
            lblMaKhoa.Size = new Size(80, 28);

            txtMaKhoa = new TextBox();
            txtMaKhoa.Location = new Point(110, 27);
            txtMaKhoa.Size = new Size(250, 28);

            Label lblMaLop = new Label();
            lblMaLop.Text = "Mã lớp";
            lblMaLop.Location = new Point(30, 72);
            lblMaLop.Size = new Size(80, 28);

            txtMaLop = new TextBox();
            txtMaLop.Location = new Point(110, 69);
            txtMaLop.Size = new Size(250, 28);

            Label lblTenLop = new Label();
            lblTenLop.Text = "Tên lớp";
            lblTenLop.Location = new Point(30, 114);
            lblTenLop.Size = new Size(80, 28);

            txtTenLop = new TextBox();
            txtTenLop.Location = new Point(110, 111);
            txtTenLop.Size = new Size(250, 28);

            btnThem = new Button();
            btnThem.Text = "Thêm";
            btnThem.Location = new Point(30, 175);
            btnThem.Size = new Size(100, 42);
            btnThem.Click += BtnThem_Click;

            btnXoa = new Button();
            btnXoa.Text = "Xóa";
            btnXoa.Location = new Point(145, 175);
            btnXoa.Size = new Size(100, 42);
            btnXoa.Click += BtnXoa_Click;

            btnSua = new Button();
            btnSua.Text = "Sửa";
            btnSua.Location = new Point(260, 175);
            btnSua.Size = new Size(100, 42);
            btnSua.Click += BtnSua_Click;

            this.Controls.AddRange(new Control[]
            {
                lblMaKhoa, txtMaKhoa,
                lblMaLop, txtMaLop,
                lblTenLop, txtTenLop,
                btnThem, btnXoa, btnSua
            });

            this.AcceptButton = btnThem;
        }

        private void BtnThem_Click(object sender, EventArgs e)
        {
            string maKhoa = txtMaKhoa.Text.Trim();
            string maLop = txtMaLop.Text.Trim();
            string tenLop = txtTenLop.Text.Trim();

            if (maKhoa == "" || maLop == "" || tenLop == "")
            {
                MessageBox.Show(
                    "Vui lòng nhập đầy đủ Mã khoa, Mã lớp và Tên lớp!",
                    "Thông báo",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }

            string sql =
                "INSERT INTO Lop (MaKhoa, MaLop, TenLop) " +
                "VALUES (@MaKhoa, @MaLop, @TenLop)";

            ThucHienLenh(sql, cmd =>
            {
                cmd.Parameters.AddWithValue("@MaKhoa", maKhoa);
                cmd.Parameters.AddWithValue("@MaLop", maLop);
                cmd.Parameters.AddWithValue("@TenLop", tenLop);
            }, "Thêm lớp thành công!");
        }

        private void BtnXoa_Click(object sender, EventArgs e)
        {
            string maKhoa = txtMaKhoa.Text.Trim();
            string maLop = txtMaLop.Text.Trim();
            string tenLop = txtTenLop.Text.Trim();

            if (maLop == "")
            {
                MessageBox.Show("Vui lòng nhập Mã lớp cần xóa!");
                txtMaLop.Focus();
                return;
            }

            if (maKhoa != "" || tenLop != "")
            {
                MessageBox.Show(
                    "Khi xóa, chỉ nhập Mã lớp.\n" +
                    "Mã khoa và Tên lớp phải để trống!");
                return;
            }

            DialogResult ketQua = MessageBox.Show(
                "Bạn có chắc muốn xóa lớp " + maLop + "?",
                "Xác nhận xóa",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (ketQua != DialogResult.Yes)
                return;

            string sql = "DELETE FROM Lop WHERE MaLop = @MaLop";

            ThucHienLenh(sql, cmd =>
            {
                cmd.Parameters.AddWithValue("@MaLop", maLop);
            }, "Xóa lớp thành công!");
        }

        private void BtnSua_Click(object sender, EventArgs e)
        {
            string maKhoa = txtMaKhoa.Text.Trim();
            string maLop = txtMaLop.Text.Trim();
            string tenLop = txtTenLop.Text.Trim();

            if (maLop == "")
            {
                MessageBox.Show("Vui lòng nhập Mã lớp cần sửa!");
                txtMaLop.Focus();
                return;
            }

            if (maKhoa == "" && tenLop == "")
            {
                MessageBox.Show(
                    "Vui lòng nhập Mã khoa hoặc Tên lớp cần sửa!");
                return;
            }

            string sql;
            if (maKhoa != "" && tenLop != "")
            {
                sql = "UPDATE Lop SET MaKhoa = @MaKhoa, " +
                      "TenLop = @TenLop WHERE MaLop = @MaLop";
            }
            else if (maKhoa != "")
            {
                sql = "UPDATE Lop SET MaKhoa = @MaKhoa " +
                      "WHERE MaLop = @MaLop";
            }
            else
            {
                sql = "UPDATE Lop SET TenLop = @TenLop " +
                      "WHERE MaLop = @MaLop";
            }

            ThucHienLenh(sql, cmd =>
            {
                cmd.Parameters.AddWithValue("@MaLop", maLop);

                if (maKhoa != "")
                    cmd.Parameters.AddWithValue("@MaKhoa", maKhoa);

                if (tenLop != "")
                    cmd.Parameters.AddWithValue("@TenLop", tenLop);
            }, "Sửa thông tin lớp thành công!");
        }

        private void ThucHienLenh(
            string sql,
            Action<SqlCommand> themThamSo,
            string thongBao)
        {
            try
            {
                using (SqlConnection conn =
                    new SqlConnection(connectionString))
                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    themThamSo(cmd);
                    conn.Open();

                    int soDong = cmd.ExecuteNonQuery();

                    if (soDong > 0)
                    {
                        MessageBox.Show(
                            thongBao,
                            "Thông báo",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Information);

                        XoaTrang();
                    }
                    else
                    {
                        MessageBox.Show(
                            "Không tìm thấy lớp có Mã lớp tương ứng!",
                            "Thông báo",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(
                    "Lỗi cơ sở dữ liệu:\n" + ex.Message,
                    "Lỗi SQL Server",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Lỗi: " + ex.Message,
                    "Thông báo",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void XoaTrang()
        {
            txtMaKhoa.Clear();
            txtMaLop.Clear();
            txtTenLop.Clear();
            txtMaKhoa.Focus();
        }
    }
}
